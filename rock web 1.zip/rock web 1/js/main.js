// Event Image API Integration (Unsplash Random)
class EventImage {
  constructor(containerId) {
    this.container = document.getElementById(containerId);
    this.apiUrl = 'https://source.unsplash.com/800x400/?concert,rock,music';
    this.loadImage();
  }
  loadImage() {
    const img = document.createElement('img');
    img.src = this.apiUrl + '&' + new Date().getTime(); // prevent caching
    img.alt = 'Latest Event';
    img.className = 'img-fluid';
    img.onload = () => {
      this.container.innerHTML = '';
      this.container.appendChild(img);
    };
    img.onerror = () => {
      this.container.innerHTML = '<div class="alert alert-danger">Could not load event image. Try again later.</div>';
    };
  }
}

// Music Player with Tabbed Navigation
class MusicPlayer {
  constructor(containerId) {
    this.container = document.getElementById(containerId);
    this.tracks = {
      Singles: [
        { title: 'Happy For You', src: 'audio/happy for you style-01.mp3', year: 2023 },
        { title: 'Slow Ballad', src: 'audio/gm mellow rock -  - Output - Stereo Out.wav', year: 2022 }
      ],
      Covers: [
        { title: 'Alone', src: 'audio/alone.mp3', year: 2024 }
      ]
    };
    const initialTab = window.location.hash.replace('#', '').replace('%20', ' ') || 'Singles';
    this.activeTab = Object.keys(this.tracks).includes(initialTab) ? initialTab : 'Singles';
    this.render();
  }
  async fetchTrackInfo(trackTitle) {
    // AudioDB API: https://www.theaudiodb.com/api/v1/json/2/searchtrack.php?s=artist&t=track
    // For demo, use a generic artist name
    const artist = 'Queen';
    const url = `https://www.theaudiodb.com/api/v1/json/2/searchtrack.php?s=${encodeURIComponent(artist)}&t=${encodeURIComponent(trackTitle)}`;
    try {
      const res = await fetch(url);
      if (!res.ok) throw new Error('API error');
      const data = await res.json();
      if (data.track && data.track[0]) {
        return data.track[0];
      } else {
        return null;
      }
    } catch (err) {
      return null;
    }
  }
  async render() {
    // Always update the section title to match the active tab
    const sectionTitle = document.getElementById('music-section-title');
    if (sectionTitle) {
      sectionTitle.textContent = this.activeTab;
    }
    this.container.innerHTML = `
      <ul class="nav nav-tabs mb-3" id="musicTabs">
        ${Object.keys(this.tracks).map(tab => `
          <li class="nav-item">
            <a class="nav-link${tab === this.activeTab ? ' active' : ''}" href="#" data-tab="${tab}">${tab}</a>
          </li>
        `).join('')}
      </ul>
      <div id="tracks-list">
        <div class="text-center text-muted">Loading tracks...</div>
      </div>
    `;
    this.addTabListeners();
    const tracks = this.tracks[this.activeTab];
    const trackCards = tracks.map((track, idx) => {
      // Highlight year in gold for Singles 2023 and 2022
      let yearHtml = `${track.year}`;
      let tabHtml = this.activeTab;
      // Image logic for Singles and Covers
      let imageHtml = '';
      let imgSrc = '';
      if (this.activeTab === 'Singles') {
        tabHtml = `<span class='track-year-gold'>${this.activeTab}</span>`;
        if (track.year === 2023 || track.year === 2022) {
          yearHtml = `<span class='track-year-gold'>${track.year}</span>`;
        }
        if (track.title === 'Happy For You') imgSrc = 'images/happy for you.jpeg';
        if (track.title === 'Slow Ballad') imgSrc = 'images/gm mellow.jpeg';
      } else if (this.activeTab === 'Covers') {
        tabHtml = `<span class='track-year-gold'>${this.activeTab}</span>`;
        if (track.title === 'Alone') imgSrc = 'images/alone.jpg';
      }
      if (imgSrc) {
        imageHtml = `
          <div class="music-track-image-container position-relative mb-3" data-idx="${idx}">
            <img src="${imgSrc}" alt="${track.title}" class="music-track-image w-100 rounded-3 shadow" id="music-img-${idx}">
          </div>
        `;
      }
      return `
        <div class="card mb-3 transition-hover">
          <div class="row g-0 align-items-center">
            <div class="col-12 d-flex flex-column align-items-center justify-content-center p-3">
              <h5 class="card-title mb-1 w-100 text-center">${track.title}</h5>
              ${imageHtml}
              <p class="card-text text-center w-100"><small class="text-muted">${tabHtml} &ndash; ${yearHtml}</small></p>
              <input type="range" min="0" value="0" step="0.01" class="form-range audio-slider my-2 w-100" id="slider-${this.activeTab}-${idx}" style="max-width: 100%;">
              <div class="audio-time d-flex justify-content-between small text-light px-1 w-100">
                <span id="current-${this.activeTab}-${idx}">0:00</span>
                <span id="duration-${this.activeTab}-${idx}">0:00</span>
              </div>
              <audio id="audio-${this.activeTab}-${idx}" controls preload="none" src="${track.src}" style="display:none;"></audio>
              <div class="d-flex justify-content-center align-items-center w-100 mt-3 singles-hide-btn">
                <button class="btn btn-lg btn-listen mx-auto px-4 py-2" data-audio="audio-${this.activeTab}-${idx}">
                  <i class="bi bi-play-fill" id="music-icon-below-${idx}"></i>
                </button>
              </div>
            </div>
          </div>
        </div>
      `;
    });
    this.container.querySelector('#tracks-list').innerHTML = trackCards.join('');
    // Add play/pause logic to buttons
    this.container.querySelectorAll('.btn-listen').forEach((btn, idx) => {
      const audioId = btn.getAttribute('data-audio');
      const audio = document.getElementById(audioId);
      const img = document.getElementById(`music-img-${idx}`);
      const icon = document.getElementById(`music-icon-below-${idx}`);
      if (!audio || !img || !icon) return;
      // Play/pause logic
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        // Pause all other audios and reset their images
        document.querySelectorAll('audio').forEach((a, i2) => {
          if (a !== audio) {
            a.pause();
            const otherImg = document.getElementById(`music-img-${i2}`);
            const otherIcon = document.getElementById(`music-icon-below-${i2}`);
            if (otherImg) otherImg.style.filter = '';
            if (otherIcon) otherIcon.className = 'bi bi-play-fill';
          }
        });
        if (audio.paused) {
          audio.play();
          icon.className = 'bi bi-pause-fill';
          img.style.filter = 'brightness(0.5)';
        } else {
          audio.pause();
          icon.className = 'bi bi-play-fill';
          img.style.filter = '';
        }
      });
      // Update image and icon on play/pause/ended
      audio.addEventListener('play', () => {
        icon.className = 'bi bi-pause-fill';
        img.style.filter = 'brightness(0.5)';
      });
      audio.addEventListener('pause', () => {
        icon.className = 'bi bi-play-fill';
        img.style.filter = '';
      });
      audio.addEventListener('ended', () => {
        icon.className = 'bi bi-play-fill';
        img.style.filter = '';
      });
    });
    // Add slider sync and seek logic
    tracks.forEach((track, idx) => {
      const audio = document.getElementById(`audio-${this.activeTab}-${idx}`);
      const slider = document.getElementById(`slider-${this.activeTab}-${idx}`);
      const current = document.getElementById(`current-${this.activeTab}-${idx}`);
      const duration = document.getElementById(`duration-${this.activeTab}-${idx}`);
      if (audio && slider) {
        audio.addEventListener('loadedmetadata', () => {
          slider.max = audio.duration;
          duration.textContent = this.formatTime(audio.duration);
        });
        audio.addEventListener('timeupdate', () => {
          slider.value = audio.currentTime;
          current.textContent = this.formatTime(audio.currentTime);
        });
        slider.addEventListener('input', () => {
          audio.currentTime = slider.value;
        });
      }
    });
  }
  addTabListeners() {
    const tabs = this.container.querySelectorAll('.nav-link');
    tabs.forEach(tab => {
      tab.addEventListener('click', e => {
        e.preventDefault();
        this.activeTab = tab.getAttribute('data-tab');
        this.render();
      });
    });
  }
  formatTime(sec) {
    sec = Math.floor(sec);
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${m}:${s.toString().padStart(2, '0')}`;
  }
}

// Booking Form Validation
class BookingForm {
  constructor(formId) {
    this.form = document.getElementById(formId);
    if (this.form) {
      this.form.addEventListener('submit', this.validate.bind(this));
    }
  }
  validate(e) {
    if (!this.form.checkValidity()) {
      e.preventDefault();
      e.stopPropagation();
    }
    this.form.classList.add('was-validated');
  }
}

// === Influence & Genre Quote Fetcher ===
if (document.getElementById('influence-quote-text')) {
  fetch('https://api.api-ninjas.com/v1/quotes', {
    headers: { 'X-Api-Key': 'zynJXBheY/6hAAPTOZ0Mww==yMul8eZpxkw3GS7t' }
  })
    .then(res => res.json())
    .then(data => {
      if (data && data[0] && data[0].quote) {
        document.getElementById('influence-quote-text').textContent = '"' + data[0].quote + '"';
      } else {
        document.getElementById('influence-quote-text').textContent = 'No quote found.';
      }
    })
    .catch(() => {
      document.getElementById('influence-quote-text').textContent = 'Could not load quote.';
    });
}

// DOMContentLoaded: Initialize features on each page
window.addEventListener('DOMContentLoaded', () => {
  if (document.getElementById('event-image-block')) {
    new EventImage('event-image-block');
  }
  if (document.getElementById('music-player-block')) {
    window.musicPlayer = new MusicPlayer('music-player-block');
  }
  if (document.getElementById('booking-form')) {
    new BookingForm('booking-form');
  }
  // Navbar Music tab dropdown integration
  document.querySelectorAll('.music-tab-link').forEach(link => {
    link.addEventListener('click', function(e) {
      e.preventDefault();
      const tab = this.getAttribute('data-tab');
      if (window.musicPlayer) {
        window.musicPlayer.activeTab = tab;
        window.musicPlayer.render();
        // Scroll to music section if not visible
        const musicSection = document.getElementById('latest-work');
        if (musicSection) {
          musicSection.scrollIntoView({ behavior: 'smooth' });
        }
      } else {
        // If not on index.html, go to index.html with hash
        window.location.href = 'index.html#latest-work';
      }
    });
  });
  // Robust dropdown menu logic for both sidebar and navbar
  // Sidebar dropdown
  let sidebarMusicToggle = document.getElementById('sidebar-music-toggle');
  let sidebarDropdownMenu = document.querySelector('.sidebar-dropdown-menu');
  if (sidebarMusicToggle && sidebarDropdownMenu) {
    sidebarMusicToggle.addEventListener('click', (e) => {
      // Only toggle dropdown if the button itself is clicked
      if (e.target === sidebarMusicToggle || sidebarMusicToggle.contains(e.target)) {
        e.preventDefault();
        if (sidebarDropdownMenu.style.display === 'block') {
          sidebarDropdownMenu.style.display = 'none';
        } else {
          sidebarDropdownMenu.style.display = 'block';
        }
      }
    });
    // Optional: close dropdown if clicking outside
    document.addEventListener('click', function(e) {
      if (!sidebarMusicToggle.contains(e.target) && !sidebarDropdownMenu.contains(e.target)) {
        sidebarDropdownMenu.style.display = 'none';
      }
    });
  }
  // Navbar dropdown
  let navbarMusicDropdown = document.getElementById('musicDropdown');
  let navbarDropdownMenu = document.querySelector('.dropdown-menu[aria-labelledby="musicDropdown"]');
  if (navbarMusicDropdown && navbarDropdownMenu) {
    navbarMusicDropdown.addEventListener('click', function(e) {
      e.preventDefault();
      navbarDropdownMenu.classList.toggle('show');
    });
    document.addEventListener('click', function(e) {
      if (!navbarMusicDropdown.contains(e.target) && !navbarDropdownMenu.contains(e.target)) {
        navbarDropdownMenu.classList.remove('show');
      }
    });
  }
}); 